-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2020 at 02:19 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eibselys_rajexim_crm`
--


-- --------------------------------------------------------

--
-- Table structure for table `folder_access`
--

CREATE TABLE `folder_access` (
  `f_acc_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `folder_access`
--

INSERT INTO `folder_access` (`f_acc_id`, `role_id`, `created_on`, `created_by`, `modified_on`, `modified_by`, `status`) VALUES
(2, 5, '2020-08-10 16:23:15', 1, '2020-08-10 17:30:54', 1, 0),
(3, 7, '2020-08-10 16:23:23', 1, '0000-00-00 00:00:00', 0, 0),
(4, 11, '2020-08-10 16:23:34', 1, '0000-00-00 00:00:00', 0, 0),
(5, 6, '2020-08-10 16:25:09', 1, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `folder_access_info`
--

CREATE TABLE `folder_access_info` (
  `f_acc_info_id` int(11) NOT NULL,
  `f_acc_id` int(11) NOT NULL DEFAULT '0',
  `folder_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `folder_access_info`
--

INSERT INTO `folder_access_info` (`f_acc_info_id`, `f_acc_id`, `folder_name`) VALUES
(4, 3, 'test'),
(5, 4, 'New'),
(7, 5, 'New'),
(8, 5, 'test'),
(11, 0, 'New'),
(14, 2, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `value_variant`
--

CREATE TABLE `value_variant` (
  `vv_id` int(11) NOT NULL,
  `vv_from_amount` double NOT NULL DEFAULT '0',
  `vv_to_amount` double NOT NULL DEFAULT '0',
  `vv_color` varchar(30) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `value_variant`
--

INSERT INTO `value_variant` (`vv_id`, `vv_from_amount`, `vv_to_amount`, `vv_color`, `created_on`, `created_by`, `modified_on`, `modified_by`, `status`) VALUES
(1, 100001, 500001, '#ff908c', '0000-00-00 00:00:00', 0, '2020-08-10 13:29:52', 1, 0),
(2, 600000, 1000000, '#ffdc91', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0),
(3, 1100000, 1500000, '#f9ffad', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0),
(4, 1600000, 2000000, '#ffd8f8', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0),
(5, 2100000, 2500000, '#bdc7fc', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0),
(6, 2600000, 3000000, '#c9ffe5', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0),
(11, 10000, 50000, '#bf8989', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `folder_access`
--
ALTER TABLE `folder_access`
  ADD PRIMARY KEY (`f_acc_id`);

--
-- Indexes for table `folder_access_info`
--
ALTER TABLE `folder_access_info`
  ADD PRIMARY KEY (`f_acc_info_id`);

--
-- Indexes for table `value_variant`
--
ALTER TABLE `value_variant`
  ADD PRIMARY KEY (`vv_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `folder_access`
--
ALTER TABLE `folder_access`
  MODIFY `f_acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `folder_access_info`
--
ALTER TABLE `folder_access_info`
  MODIFY `f_acc_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `value_variant`
--
ALTER TABLE `value_variant`
  MODIFY `vv_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
