<?php $this->load->view('common_header'); $date_format =common_date_format();?>



            <!-- END: Left Aside -->

            <div class="m-grid__item m-grid__item--fluid m-wrapper">

               <!-- BEGIN: Subheader -->

               <div class="m-subheader ">

                  <div class="d-flex align-items-center">

                     <div class="mr-auto">

                        <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">

                           <li class="m-nav__item m-nav__item--home">

                              <a href="#" class="m-nav__link m-nav__link--icon">

                                 <i class="m-nav__link-icon fa fa-home"></i>

                              </a>

                           </li>

                           <li class="m-nav__separator"><i class="fa fa-angle-double-right"></i></li>

                           <li class="m-nav__item">

                              <a href="<?php echo base_url(); ?>buyerorder" class="m-nav__link">

                                 <span class="m-nav__link-text">Buyer Order</span>

                              </a>

                           </li>

                        </ul>

                     </div>

                  </div>

               </div>



               <!-- END: Subheader -->

               <div class="m-content">

               <?php if($this->session->flashdata('purchase_success')){?>

               <div class="alert alert-success alert-dismissible response" role="alert">

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                  </button>

                  <?php echo $this->session->flashdata('purchase_success'); ?>               

               </div>

               <?php } ?> 

               <?php if($this->session->flashdata('purchase_err')){?>

               <div class="alert alert-danger alert-dismissible response" role="alert">

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                  </button>

                  <?php echo $this->session->flashdata('purchase_err'); ?>                

               </div>

               <?php } ?> 



                  <!--Begin::Section-->

                  <div class="row">

                     <div class="col-xl-12">

                        <div class="m-portlet m-portlet--mobile ">

                           <div class="m-portlet__head">

                              <div class="m-portlet__head-caption">

                                 <div class="m-portlet__head-title">

                                    <h3 class="m-portlet__head-text">

                                      Buyer Order List

                                    </h3>

                                 </div>

                              </div>

                              <div class="m-portlet__head-tools">

                                 <ul class="m-portlet__nav">



                                    <li class="m-portlet__nav-item">

                                       <a href="#" onclick="bo_export_items();" class="m-portlet__nav-link btn btn--sm m-btn--pill btn-secondary m-btn m-btn--label-brand">

                                          Export

                                       </a>

                                    </li>

                                 </ul>

                              </div>

                           </div>

                           <div class="m-portlet__body">



                              <?php if($this->session->flashdata('qstage_success')){?>

                                   <div class="alert alert-success alert-dismissible fade show" role="alert" id="alertaddmessage">

                                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                    </button>

                                    <?php echo $this->session->flashdata('qstage_success'); ?>

                                 </div>

                                 <?php } ?>



                              <?php if($this->session->flashdata('qstage_err')){?>

                                      <div class="alert alert-danger alert-dismissible fade show" role="alert" id="alertaddmessage">

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                                    </button>

                                    <?php echo $this->session->flashdata('qstage_err'); ?>

                                 </div>

                                 <?php } ?>  

                              <!--begin: Datatable -->



                              <div class="row"> 

                                 <div class="col-lg-12">  

                                    <table class="table table-striped- table-bordered table-hover table-checkable" id="m_table_2">

                                       <thead>

                                          <tr>

                                             <th>Invoice No / Date</th>

                                             <th>Exporter</th>

                                             <th>Consignee</th>

                                             <th>No.of Products</th>

                                             <th>Country</th>

                                             <th>Stages</th>
                                             <th>Total Value</th>
                                             <th>Action</th>

                                          </tr>

                                       </thead>

                                       <tbody>

                                          <?php $i=0;foreach ($buyer_order_list as $qlist){

                                             $qprod = $this->Buyerorder_model->get_buyer_order_product_by_id($qlist['buyer_order_id']);
                                             $get_value_variant_by_order_Value = get_value_variant_by_value($qlist['grand_total']);
                                             $value_based_color = $get_value_variant_by_order_Value->vv_color;
                                             ?>

                                          <tr>

                                             <td>

                                                

                                                <h5 class="text-black" style="margin-bottom: 0px;"><?php echo $qlist['buyer_order_invoice_no'];?></h5>

                                                <span style="font-size: 16.5px;" class="text-muted"><b><sub><?php echo date($date_format, strtotime($qlist['invoice_date'])); ?></sub><b></b></b></span>

                                                

                                             </td> 

                                             <td>

                                                <?php echo $qlist['exporter_name'];?>

                                             </td>

                                             <td>

                                                <?php echo $qlist['lead_name'];?>

                                             </td>

                                             <td align="center">

                                                <h5 class="text-black"><?php echo count($qprod);?></h5>

                                             </td>

                                             <td align="center">

                                                <?php echo $qlist['country_name'];?>

                                             </td>

                                             <td>

                                               <h5 class="text-black"><?php echo $qlist['pi_stage'];?></h5>

                                             </td>

                                             <td style="background-color: <?php echo $value_based_color; ?>;">
                                                
                                               <h5 class="text-black">
                                                   <span class="pull-left">
                                                      <i class="fa fa-rupee-sign"></i>
                                                   </span>
                                                   <span class="pull-right"><?php echo number_format($qlist['grand_total'],2);?></span>
                                                </h5>
                                                <h6 class="text-primary curr_amnt_info">
                                                   <span class="pull-right"> <?php $convert_curr = $qlist['grand_total'] / $qlist['rate']; echo $qlist['currency_code'].' '.number_format($convert_curr,2); ?></span>
                                                </h6>

                                             </td>

                                             <td>



                                                <a href="<?php echo base_url(); ?>buyerorder/buyerorder_task/<?php echo $qlist['buyer_order_id']; ?>">

                                                <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="" data-original-title="Task"><i class="fa fa-spinner"></i></span>

                                                </a>&nbsp;&nbsp;



                                                <?php if($_SESSION['Buyer OrderView']==1){ ?>

                                                <a href="<?php echo base_url(); ?>buyerorder/buyerorder_view/<?php echo $qlist['buyer_order_id'];?>"><span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="View"><i class="fa fa-info-circle"></i></span></a>&nbsp;&nbsp;

                                                <?php }?>



                                                <a href="<?php echo base_url(); ?>buyerorder/buyerorder_verify_files/<?php echo $qlist['buyer_order_id']; ?>">

                                                <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="" data-original-title="Upload Verified Doc"><i class="fa fa-file-upload"></i></span>

                                                </a>&nbsp;&nbsp;



                                                <a href="<?php echo base_url(); ?>buyerorder/invoice_copy/<?php echo $qlist['buyer_order_id']; ?>">

                                                   <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="Invoice Copy" ><i class="fa fa-copy"></i></span>

                                                </a>&nbsp;&nbsp;

                                                <a href="<?php echo base_url(); ?>buyerorder/po_feedback/<?php echo $qlist['buyer_order_id']; ?>">

                                                <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="" data-original-title="Order Feedback"><i class="fa fa-comment-dots"></i></span>

                                                </a>&nbsp;&nbsp;

                                                <?php if($qlist['is_complete']==0){?>

                                                <a href="javascript:;" data-toggle="modal" data-target="#bo_complete" onclick="return bo_complete(<?php echo $qlist['buyer_order_id']; ?>);" ><span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="Complete"><i class="fa fa-check-circle"></i></span></a>

                                                <?php }?>



                                                <a href="<?php echo base_url(); ?>buyerorder/followup_sheet/<?php echo $qlist['buyer_order_id']; ?>">

                                                   <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="Follow up" ><i class="flaticon-calendar-with-a-clock-time-tools"></i></span>

                                                </a>&nbsp;&nbsp;



                                                <a href="<?php echo base_url(); ?>buyerorder/benefit_sheet/<?php echo $qlist['buyer_order_id']; ?>">

                                                   <span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="Benefit" ><i class="la la-money"></i></span>

                                                </a>&nbsp;&nbsp;

                                             </td>

                                          </tr>

                                          <?php $i++;}?>

                                       </tbody>

                                    </table>

                                 </div>

                              </div>

                           </div>

                        </div>

                     </div>

                  </div>



                  <!--End::Section-->

               </div>

            </div>

         </div>



<!--buyer order complete-->

<div class="container">

    <div class="modal fade" id="bo_complete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

       

    </div>

   </div>

   

   



<div class="container">

   <div class="modal fade" id="bo_export_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

      <div class="modal-dialog modal-lg" role="document">

         <div class="modal-content">

            <div class="modal-header">

               <h5 class="modal-title" id="exampleModalLabel">Export Buyer Order Info</h5>

               <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                  <span aria-hidden="true">&times;</span>

               </button>

            </div>

            <form action="<?php echo base_url(); ?>Leads/export_bo_info" method="POST">

               <div class="modal-body">

                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_lead_name" class = "bo_export" name="bo_export[]" value="Lead Name"><label class="label" for="exp_lead_name">Lead Name</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_quo_no" class = "bo_export" name="bo_export[]" value="Buyer Order Invoice No"><label class="label" for="exp_quo_no">Buyer Order Invoice No</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_exporter" class = "bo_export" name="bo_export[]" value="Exporter"><label class="label" for="exp_exporter">Exporter</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_subject" class = "bo_export" name="bo_export[]" value="Subject"><label class="label" for="exp_subject">Subject</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_cre_date" class = "bo_export" name="bo_export[]" value="Invoice Date"><label class="label" for="exp_cre_date">Invoice Date</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_con_date" class = "bo_export" name="bo_export[]" value="Buyer Confirmation Date"><label class="label" for="exp_con_date">Buyer Confirmation Date</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_bo_stage" class = "bo_export" name="bo_export[]" value="PI Stage"><label class="label" for="exp_bo_stage">PI Stage</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_other_ref" class = "bo_export" name="bo_export[]" value="Other Reference"><label class="label" for="exp_other_ref">Other Reference</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_terms_of_payment_type" class = "bo_export" name="bo_export[]" value="Terms Of Payment Type"><label class="label" for="exp_terms_of_payment_type">Terms of Payment Type</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_pre_car" class = "bo_export" name="bo_export[]" value="Pre Carriage By"><label class="label" for="exp_pre_car">Pre Carriage By</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_place_of_rec" class = "bo_export" name="bo_export[]" value="Place Of Reciept By Pre Carrier"><label class="label" for="exp_place_of_rec">Place Of Reciept By Pre Carrier</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_vessel_flight_id" class = "bo_export" name="bo_export[]" value="Vessel Flight"><label class="label" for="exp_vessel_flight_id">Vessel Flight</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_pol" class = "bo_export" name="bo_export[]" value="Port Of Loading"><label class="label" for="exp_pol">Port Of Loading</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_pod" class = "bo_export" name="bo_export[]" value="Port Of Discharge"><label class="label" for="exp_pod">Port Of Discharge</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_fin_dest" class = "bo_export" name="bo_export[]" value="Final Destination"><label class="label" for="exp_fin_dest">Final Destination</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_curr" class = "bo_export" name="bo_export[]" value="Currency"><label class="label" for="exp_curr">Currency</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_rate" class = "bo_export" name="bo_export[]" value="Rate"><label class="label" for="exp_rate">Rate</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_bank_det" class = "bo_export" name="bo_export[]" value="Bank Info"><label class="label" for="exp_bank_det">Bank Info</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_sales_note" class = "bo_export" name="bo_export[]" value="Sales Note"><label class="label" for="exp_sales_note">Sales Note</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_pur_note" class = "bo_export" name="bo_export[]" value="Purchase Note"><label class="label" for="exp_pur_note">Purchase Note</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_ship_not" class = "bo_export" name="bo_export[]" value="Shipping Note"><label class="label" for="exp_ship_not">Shipping Note</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_acc_note" class = "bo_export" name="bo_export[]" value="Account Note"><label class="label" for="exp_acc_note">Account Note</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_spe_pack_det" class = "bo_export" name="bo_export[]" value="Specification Packing Details"><label class="label" for="exp_spe_pack_det">Specification Packing Details</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_price_validity" class = "bo_export" name="bo_export[]" value="Price Validity"><label class="label" for="exp_price_validity">Price Validity</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_interest" class = "bo_export" name="bo_export[]" value="Interest"><label class="label" for="exp_interest">Interest</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_loadability" class = "bo_export" name="bo_export[]" value="Loadability"><label class="label" for="exp_loadability">Loadability</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_terms_and_payment" class = "bo_export" name="bo_export[]" value="Terms And Payment"><label class="label" for="exp_terms_and_payment">Terms And Payment</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_terms_of_payment" class = "bo_export" name="bo_export[]" value="Terms Of Payment"><label class="label" for="exp_terms_of_payment">Terms Of Payment</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>



                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_ord_date" class = "bo_export" name="bo_export[]" value="Order Date"><label class="label" for="exp_ord_date">Order Date</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_ord_end_date" class = "bo_export" name="bo_export[]" value="Order End Date"><label class="label" for="exp_ord_end_date">Order End Date</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_arbitration" class = "bo_export" name="bo_export[]" value="Arbitration"><label class="label" for="exp_arbitration">Arbitration</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_declaration" class = "bo_export" name="bo_export[]" value="Declaration"><label class="label" for="exp_declaration">Declaration</label>

                             <span></span>

                           </label>

                        </div>

                     </div>   

                  </div>

                  <div class="row">

                     <div class="col-lg-3">

                        <div class="bank m-checkbox-inline">

                           <label class="m-checkbox">

                             <input type="checkbox" id="exp_grand_tot" class = "bo_export" name="bo_export[]" value="Grand Total"><label class="label" for="exp_grand_tot">Grand Total</label>

                             <span></span>

                           </label>

                        </div>

                     </div>

                  </div>

               </div>

               <div class="modal-footer">

                  <div class="bank m-checkbox-inline">

                     <label class="m-checkbox">

                       <input type="checkbox" onclick="toggle(this)"><label class="label">All</label>

                       <span></span>

                     </label>

                  </div>&nbsp;

                 <button type="submit" class="btn btn-primary">Yes</button>

                 <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>

               </div>

            </form>

         </div>

      </div>

   </div>

</div>



         <!-- end:: Body -->



         <!-- begin::Footer -->

         <?php $this->load->view('common_footer'); ?>



         <!-- end::Footer -->

      </div>



      <!-- end:: Page -->





<script type="text/javascript">

   var baseurl = '<?php echo base_url(); ?>';

   var title = $('title').text() + ' | ' + 'Buyer Order List';

   $(document).attr("title", title);



function bo_complete(val){

$.ajax({

type: "POST",

url: baseurl+'buyerorder/bo_complete',

async: false,

type: "POST",

data: "id="+val,

dataType: "html",

success: function(response)

{

$('#bo_complete').empty().append(response);

}

});

}



function completeBO(val)

{ 

//var baseurl= $("#baseUrl").val();

$.ajax({

type: "POST",

url: baseurl+'buyerorder/completeBO',

async: false,

data:"boid="+val,

success: function(response)

{

window.location.href = baseurl+'buyerorder';

}

});

}

function bo_export_items()

{

   $('#bo_export_model').modal('show');

}

function toggle(source) {

      

   checkboxes = document.getElementsByClassName('bo_export');

   for(var i=0, n=checkboxes.length;i<n;i++) {

      checkboxes[i].checked = source.checked;

   }

}



</script>





   </body>



   <!-- end::Body -->

</html>