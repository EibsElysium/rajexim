<!-- <div class="row">
	<div class="col-md-3">
        <div class="panel">
            <div class="pad-all bord-btm">
                <a href="javascript:;" onclick="compose_mail();" class="btn btn-block btn-primary"><i class="fa fa-plus"></i>&nbsp; &nbsp; Compose</a>
                <input type="hidden" name="email_name" id="email_name" value="<?php echo $email_name; ?>">
            </div>
        </div>
    </div>
    <div class="col-md-3">
    	<div class="panel">
    	<div class="list-group bg-trans pad-btm bord-btm">
                <a href="javascript:;" onclick="get_info_email_list();" class="list-group-item text-semibold text-main">

                     <span class="badge badge-success pull-right" id="inbox_unread"></span> 
                    <span class="text-main"><i class="mailbox-pli-inbox-full icon-lg icon-fw"></i> Inbox</span>
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
    	<div class="panel">
    	<div class="list-group bg-trans pad-btm bord-btm">
    	 	<a href="javascript:;" onclick="get_info_sent_email_list();" class="list-group-item text-semibold text-main">
                     <span class="badge badge-success pull-right" id="sent_unread"></span> 
                    <span class="text-main"><i class="la la-send mail_la_ico" style="font-size: 21px;"></i> Sent Items</span>
                </a>
         </div>
     </div>
    </div>
    <div class="col-md-3">
    	<div class="panel">
    	<div class="list-group bg-trans pad-btm bord-btm">
    		<a href="javascript:;" onclick="get_info_draft_email_list();" class="list-group-item text-semibold text-main">
                     <span class="badge badge-success pull-right" id="draft_unread"></span> 
                    <span class="text-main"><i class="la la-file-text mail_la_ico" style="font-size: 21px;"></i> Drafts</span>
                </a>
         </div>
     </div>
    </div>
</div> -->
<style>
	.tap_size {
		height: 31px;
	}
</style>
<div class="row">
	<div class="col-md-12">
	    <div style="margin-bottom:2.2rem;">
	          <ul class="que_sett">
	             <!-- <li class=""><a class="tap_size" href="javascript:;" onclick="compose_mail();"><i class="fa fa-plus"></i>&nbsp; &nbsp;Compose</a></li> -->
	             <li class=""><button type="button" onclick="compose_mail();" class="btn btn-primary tap_size"><i class="fa fa-plus"></i>&nbsp; &nbsp;Compose</button></li>
	             <input type="hidden" name="email_name" id="email_name" value="<?php echo $email_name; ?>">

	             <li class=""><button type="button" onclick="get_info_email_list();" class="btn btn-primary tap_size"><i class="mailbox-pli-inbox-full icon-lg icon-fw"></i>&nbsp; &nbsp;Inbox</button></li>
	             <!-- <li class="" ><a class="tap_size" href="javascript:;" onclick="get_info_email_list();"><i class="mailbox-pli-inbox-full icon-lg icon-fw"></i>&nbsp; &nbsp;Inbox</a></li> -->

	             <li class=""><button type="button" onclick="get_info_sent_email_list();" class="btn btn-primary tap_size"><i class="la la-send mail_la_ico" style="font-size: 21px;"></i> &nbsp; &nbsp;Sent Items</button></li>

	             <!-- <li class="" ><a class="tap_size" href="javascript:;" onclick="get_info_sent_email_list();"><i class="la la-send mail_la_ico" style="font-size: 21px;"></i> &nbsp; &nbsp;Sent Items</a></li> -->
	             <li class=""><button type="button" onclick="get_info_draft_email_list();" class="btn btn-primary tap_size"><i class="la la-file-text mail_la_ico" style="font-size: 21px;"></i> &nbsp; &nbsp;Drafts</button></li>
	             
	             <!-- <li class="" ><a class="tap_size" href="javascript:;" onclick="get_info_draft_email_list();"><i class="la la-file-text mail_la_ico" style="font-size: 21px;"></i> &nbsp; &nbsp;Drafts</a></li> -->
	          </ul>
	    </div>
	</div>
</div> 
<div class="row">
    

	    <div class="col-md-12" id="email_list_view">
	    	<!-- Image loader -->
			<div id='loader' style='display: none;'>
			   <div class="se-pre-con">
			   	
			   </div>
			</div>
			<!-- Image loader -->
	    </div>
	    <input type="hidden" name="start" id="start" value="<?php echo $start; ?>">
	    <input type="hidden" name="end" id="end" value="<?php echo $end; ?>">
	    <input type="hidden" name="per_page" id="per_page" value="<?php echo $per_page; ?>">
	    <input type="hidden" name="mail_list_count" id="mail_list_count" value="<?php echo $mail_list_count; ?>">
	    <input type="hidden" name="tot_mail_list_count" id="tot_mail_list_count" value="<?php echo $tot_mail_list_count; ?>">
	    <input type="hidden" name="displayed_mail_list_count" id="displayed_mail_list_count" value="<?php echo $displayed_mail_list_count; ?>">
	    
</div>
<script>
	$(document).ready(function(){
		get_info_email_list();
	});
	function get_info_email_list()
	{	
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		var start = $('#start').val();
		var end = $('#end').val();
		var per_page = $('#per_page').val();
		var mail_list_count = $('#mail_list_count').val();
		var tot_mail_list_count = $('#tot_mail_list_count').val();
		var displayed_mail_list_count = $('#displayed_mail_list_count').val();
		var mailbox_array = '<?php echo str_replace("'","`",json_encode($mail_lists)); ?>';

		//alert(mailbox_array);
		$.ajax({
		type: "POST",
		url: baseurl+'Mailbox/info_email_list',
		
		type: "POST",
		data:{'emailid':emailid, 'start':start, 'end':end, 'per_page' : per_page, 'mail_list_count' : tot_mail_list_count, 'mailbox_array': mailbox_array, 'tot_mail_list_count' : tot_mail_list_count, 'displayed_mail_list_count' : displayed_mail_list_count},
		dataType: "html",
		success: function(response)
		{
			$('#email_calling').hide();
			$('#email_list_view').empty().append(response);	
		}
		
		});
	}
	$(document).ready(function(){
		get_unread_mails_count();
	});
	function get_unread_mails_count()
	{
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		$.ajax({
			type: "POST",
			url: baseurl+'Mailbox/get_unread_mails_count',
			
			type: "POST",
			data:{'emailid':emailid},
			dataType: "html",
			success: function(response)
			{
				$('#email_calling').hide();
				var res_array = response.split('|');
				// setInterval(function(){
				//     $('#inbox_unread').append(res_array[0]);
				// 	$('#sent_unread').append(res_array[1]);
				// 	$('#draft_unread').append(res_array[2]);
				// }, 2000);
				if (res_array[0] != 0) {
					// $('#inbox_unread').append(res_array[0]);
				}
				else {
					$('#inbox_unread').hide();
				}
				$('#sent_unread').append(res_array[1]);
				$('#draft_unread').append(res_array[2]);
			}
		});
	}
	function get_another_part_of_list(second_index,first_index,start,end)
    {
    	$('#email_calling').show();
        var emailid = $('#info_email').val();
        var per_page = '<?php echo $per_page; ?>';
        var mail_list_count = $('#tot_mail_list_count').val();
       
        $.ajax({
            type: "POST",
            url: baseurl+'Mailbox/get_pagination_based_email_list',
            
            type: "POST",
            data:{'emailid':emailid, 'second_index':second_index, 'first_index':first_index, 'per_page' : per_page, 'start':start, 'end':end, 'tot_mail_list_count' : mail_list_count},
            dataType: "html",
            success: function(response)
            {
            	$('#email_calling').hide();
                $('#email_list_view').empty().append(response);
                
            }
        
        });
    }
	function get_info_sent_email_list()
	{
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		//alert(mailbox_array);
		$.ajax({
		type: "POST",
		url: baseurl+'Mailbox/info_sent_email_list',
		
		type: "POST",
		data:{'emailid':emailid},
		dataType: "html",
		success: function(response)
		{
			$('#email_calling').hide();
			$('#email_list_view').empty().append(response);	
		}
		
		});
	}
	function get_another_part_of_sent_list(second_index,first_index,start,end, tot_sent_mail)
    {
    	$('#email_calling').show();
        var emailid = $('#info_email').val();
        var per_page = '<?php echo $per_page; ?>';
       
        $.ajax({
            type: "POST",
            url: baseurl+'Mailbox/get_send_pagination_based_email_list',
            
            type: "POST",
            data:{'emailid':emailid, 'second_index':second_index, 'first_index':first_index, 'per_page' : per_page, 'start':start, 'end':end, 'tot_mail_list_count' : tot_sent_mail},
            dataType: "html",
            success: function(response)
            {
            	$('#email_calling').hide();
                $('#email_list_view').empty().append(response);
                
            }
        
        });
    }
	function get_info_draft_email_list()
	{
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		//alert(mailbox_array);
		$.ajax({
		type: "POST",
		url: baseurl+'Mailbox/info_draft_email_list',
		
		type: "POST",
		data:{'emailid':emailid},
		dataType: "html",
		success: function(response)
		{
			$('#email_calling').hide();
			$('#email_list_view').empty().append(response);	
		}
		
		});
	}
	function imap_mailbox_view(msgno, label, start, end, per_page, first_index, second_index)
	{
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		var tot_mail_list_count = '<?php echo $tot_mail_list_count; ?>';
		$.ajax({
		type: "POST",
		url: baseurl+'Mailbox/imap_mailbox_view',
		
		type: "POST",
		data:{'emailid':emailid, 'msgno':msgno, 'label':label, 'start' : start, 'end' : end, 'per_page' : per_page, 'tot_mail_list_count' : tot_mail_list_count, 'first_index' : first_index, 'second_index' : second_index },
		dataType: "html",
		success: function(response)
		{
			$('#email_calling').hide();
			$('#email_list_view').empty().append(response);
			
		}
		});

	}
	function sent_imap_mailbox_view(msgno, label, start, end, per_page, tot_sent_mail, first_index, second_index)
	{
		$('#email_calling').show();
		var emailid = $('#info_email').val();
		
		$.ajax({
		type: "POST",
		url: baseurl+'Mailbox/sent_imap_mailbox_view',
		
		type: "POST",
		data:{'emailid':emailid, 'msgno':msgno, 'label':label, 'start' : start, 'end' : end, 'per_page' : per_page, 'tot_mail_list_count' : tot_sent_mail, 'first_index' : first_index, 'second_index' : second_index},
		dataType: "html",
		success: function(response)
		{
			$('#email_calling').hide();
			$('#email_list_view').empty().append(response);
			
		}
		});

	}
</script>