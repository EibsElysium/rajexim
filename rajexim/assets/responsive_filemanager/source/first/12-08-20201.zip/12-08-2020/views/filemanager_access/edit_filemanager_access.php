<div class="modal-dialog modal-md" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalLabel">Edit File Manager Access</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            
            <form method="POST" enctype="multipart/form-data" action="<?php echo base_url(); ?>Settings/update_f_acc" onsubmit="return update_f_acc_validation()">
               <div class="modal-body">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="row">
                           <div class="col-lg-12">
                              <div class="form-group m-form__group">
                                 <input type="hidden" name="f_acc_id" value="<?php echo $get_fa_by_id->f_acc_id; ?>">
                                 <label>Role<span class="text-danger">*</span></label>
                                 <select class="form-control m-bootstrap-select m_selectpicker" onchange="e_check_unique_role();" data-live-search="true" name="e_role" id="e_role">
                                    <option value="">All</option>
                                    <?php
                                       if(!empty($get_all_role_name))
                                       {
                                    foreach ($get_all_role_name as $role_info) { if($role_info->status == 0){ ?>
                                    <option <?php echo ($get_fa_by_id->role_id == $role_info->role_id) ? 'selected' : ''; ?> value="<?php echo $role_info->role_id; ?>" ><?php echo $role_info->role_name; ?></option>
                                    <?php } }
                                       }
                                       ?>
                                 </select>
                                 <input type="hidden" name="ex_role" id="ex_role" value="<?php echo $get_fa_by_id->role_id; ?>">
                                 <span id="e_role_err" class="text-danger"></span>
                              </div>
                           </div>
                        </div>
                        
                        <div class="row">
                           <div class="col-lg-12">
                              <div class="form-group m-form__group">
                                 <label>Folders<span class="text-danger">*</span></label>
                                 <select class="form-control m-bootstrap-select m_selectpicker" data-live-search="true" name="e_folders[]" id="e_folders" multiple>
                                   
                                    <?php
                                       if(!empty($get_all_folders))
                                       {
                                    foreach ($get_all_folders as $fold_info) {  
                                       $get_folder_name = str_replace('assets/responsive_filemanager/source/', '', $fold_info);
                                       ?>
                                    <option <?php if (in_array($get_folder_name, $get_fai_by_id)) { echo 'selected'; } ?> value="<?php echo $get_folder_name; ?>" ><?php echo $get_folder_name; ?></option>
                                    <?php } 
                                       }
                                       ?>
                                 </select>
                                 <span id="e_folders_err" class="text-danger"></span>
                              </div>
                           </div>
                        </div>
                        
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="submit" id="e_btnSubmit" class="btn btn-primary">Create</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </form>
         </div>
      </div>
      <script>
         $('.m_selectpicker').selectpicker();
           var eexpo = 0;
   
   function e_check_unique_role()
   
   {
   
      var val = $('#e_role').val();
      var ex_val = $('#ex_role').val();

      if (val != ex_val) {
         $.ajax({
      
            type:"POST",
      
            url:baseurl+'Settings/check_unique_role',
      
            data:{'value':val},
      
            cache: false,
      
            dataType: "html",
      
            success: function(result){
               if(result>0)
      
               {
            
                  $('#e_role_err').html('Role is already exists!');
      
                  $('#e_btnSubmit').prop('disabled', true);
      
                  eexpo = 1;
      
               }
      
               else
      
               {
      
                  $('#e_role_err').html('');
      
                  $('#e_btnSubmit').prop('disabled', false);
      
                  eexpo = 0;
      
               }
      
            }
      
         });
      }
   
   }
   function update_f_acc_validation()
   {
      var err = 0;
   
      var role = $('#e_role').val();
   
      var folders = $('#e_folders').val();
   
      if(role == '')
   
      {
   
         $('#e_role_err').html('Role is required!');
   
         err++;
   
      }else{
   
         if(expo == 1)
   
         {
   
            $('#e_role_err').html('Role is already exists!');
   
            err++;
   
         }
   
         else
   
         {
   
            $('#e_role_err').html('');
   
         }
   
      }
   
      if (folders == '') {
   
         $('#e_folders_err').html('Folders is required!');
   
         err++;
   
      }
   
      else {
   
         $('#e_folders_err').html('');
   
      }
   
      if(err> 0){ return false;}else{ return true; }   
   }
      </script>   
