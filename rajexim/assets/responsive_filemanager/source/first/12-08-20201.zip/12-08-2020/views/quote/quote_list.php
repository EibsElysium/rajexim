<?php $this->load->view('common_header'); $date_format =common_date_format();?>
<style>
   .curr_amnt_info {
      font-size: 11px;
   }
   .grand_total:hover{
      background-color: #fff;
   }
</style>
            <!-- END: Left Aside -->
            <div class="m-grid__item m-grid__item--fluid m-wrapper">

               <!-- BEGIN: Subheader -->
               <div class="m-subheader ">
                  <div class="d-flex align-items-center">
                     <div class="mr-auto">
                        <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
                           <li class="m-nav__item m-nav__item--home">
                              <a href="#" class="m-nav__link m-nav__link--icon">
                                 <i class="m-nav__link-icon fa fa-home"></i>
                              </a>
                           </li>
                           <li class="m-nav__separator"><i class="fa fa-angle-double-right"></i></li>
                           <li class="m-nav__item">
                              <a href="<?php echo base_url(); ?>quote" class="m-nav__link">
                                 <span class="m-nav__link-text">Quote Management</span>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>

               <!-- END: Subheader -->
               <div class="m-content">
                  <!--Begin::Section-->
                  <div class="row">
                     <div class="col-xl-12">
                        <div class="m-portlet m-portlet--mobile ">
                           <div class="m-portlet__head">
                              <div class="m-portlet__head-caption">
                                 <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                      Quote List
                                    </h3>
                                 </div>
                              </div>
                              <div class="m-portlet__head-tools">
                                 <ul class="m-portlet__nav">
                                    <?php if($_SESSION['Quote ManagementAdd']==1){ ?>
                                    <li class="m-portlet__nav-item">
                                       <a href="<?php echo base_url(); ?>quote/quote_add" class="btn btn-primary m-btn m-btn--custom m-btn--icon m-btn--air">
                                          <span>
                                             <i class="la la-plus"></i>
                                             <span>Create Quote</span>
                                          </span>
                                       </a>
                                    </li>
                                    <?php } ?>
                                    <li class="m-portlet__nav-item">
                                       <a href="#" onclick="quote_export_items();" class="m-portlet__nav-link btn btn--sm m-btn--pill btn-secondary m-btn m-btn--label-brand">
                                          Export
                                       </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                           <div class="m-portlet__body">

                              <?php if($this->session->flashdata('qstage_success')){?>
                                   <div class="alert alert-success alert-dismissible fade show" role="alert" id="alertaddmessage">
                                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    </button>
                                    <?php echo $this->session->flashdata('qstage_success'); ?>
                                 </div>
                                 <?php } ?>

                              <?php if($this->session->flashdata('qstage_err')){?>
                                      <div class="alert alert-danger alert-dismissible fade show" role="alert" id="alertaddmessage">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    </button>
                                    <?php echo $this->session->flashdata('qstage_err'); ?>
                                 </div>
                                 <?php } ?>  
                              <!--begin: Datatable -->

                              <form method="POST" action="<?php echo base_url();?>quote">
                                 <div class="row">
                                    <div class="col-lg-2">
                                       <?php if($_SESSION['admindata']['role_id'] == 1) { ?>  
                                          <label>Users</label>
                                       <select class="form-control m-bootstrap-select m_selectpicker" data-live-search="true" name="quo_sales_user" id="quo_sales_user" onchange="this.form.submit();">
                                          <option value="">All Users</option>
                                          <?php foreach($user_list as $ulist){
                                            if($ulist['role_id']!=1){ ?>
                                            <option <?php echo ($quo_users == $ulist['user_id']) ? 'selected' : ''; ?> value='<?php echo $ulist['user_id'];?>'><?php echo $ulist['name'];?></option>
                                          <?php } } ?>
                                       </select>
                                       <?php } else { ?>
                                         <input type="hidden" name="quo_sales_user" id="quo_sales_user" value="<?php echo $_SESSION['admindata']['user_id']; ?>">
                                       <?php } ?>
                                    </div>
                                    <div class="col-lg-2">
                                       <label>Quote Stage</label>
                                       <select class="form-control m-bootstrap-select m_selectpicker" data-live-search="true" name="quo_stage_filt" id="quo_stage_filt" onchange="this.form.submit();" multiple>
                                          <option value="">All Quote Stage</option>
                                          <?php foreach ($quote_stage_list as $quote_stage) { ?>
                                                   <option <?php echo (in_array($quote_stage['quote_stage_id'], $quote_stage)) ? 'selected' : ''; ?> value="<?php echo $quote_stage['quote_stage_id']; ?>"><?php echo $quote_stage['quote_stage']; ?></option>
                                                   
                                           <?php } ?>>
                                       </select>
                                    </div>
                                    <div class="col-lg-2">
                                       <div class="form-group m-form__group">
                                          <label>Filter Based On</label>
                                          <select class="custom-select form-control" id="fbase" name="fbase" onchange="showFBase();">
                                             <option value="" <?php if($fbasesearch=='') echo "selected";?>>Select</option>
                                             <option value="BonQuarter" <?php if($fbasesearch=='BonQuarter') echo "selected";?>>Quarter</option>
                                             <option value="BonDate" <?php if($fbasesearch=='BonDate') echo "selected";?>>Date</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 boq" style="<?php echo $fbasesearch=='BonQuarter'?'':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label>Quarter</label>
                                          <select class="custom-select form-control" id="fquarter" name="fquarter">
                                             <option value="" <?php if($fquartersearch=='') echo "selected";?>>Select</option>
                                             <option value="Q1" <?php if($fquartersearch=='Q1') echo "selected";?>>Q1</option>
                                             <option value="Q2" <?php if($fquartersearch=='Q2') echo "selected";?>>Q2</option>
                                             <option value="Q3" <?php if($fquartersearch=='Q3') echo "selected";?>>Q3</option>
                                             <option value="Q4" <?php if($fquartersearch=='Q4') echo "selected";?>>Q4</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 boq" style="<?php echo $fbasesearch=='BonQuarter'?'':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label>Year</label>
                                          <div class="m-input-icon pull-right">
                                             <input type="text" id="ypick" name="ypick" class="form-control" placeholder="Choose Year" value="<?php echo $ypick;?>" readonly>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 boq" style="<?php echo $fbasesearch=='BonQuarter'?'':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label></label>
                                          <input id="goButtonboq" name="goButtonboq" value="Go" class="btn btn-primary inp" style="margin-top:26px;" type="submit">
                                       </div>
                                    </div>
                                    
                                    <div class="col-lg-2 bod" style="<?php echo $fbasesearch=='BonDate'?'':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label>Filter By</label>
                                          <select class="custom-select form-control" id="searchChange" name="searchChange" onchange="if (this.value!='thisDate') {this.form.submit();} else {showFilterDate();}">
                                             <option value="" <?php if($purchasesearch=='') echo "selected";?>>Select</option>
                                             <option value="today" <?php if($purchasesearch=='today') echo "selected";?>>Today</option>
                                                  <option value="thisweek" <?php if($purchasesearch=='thisweek') echo "selected";?>>This Week</option>
                                                  <option value="thismonth" <?php if($purchasesearch=='thismonth') echo "selected";?>>This Month</option>
                                                  <option value="thisyear" <?php if($purchasesearch=='thisyear') echo "selected";?>>This Year</option>
                                                   <option value="thisDate" <?php if($purchasesearch=='thisDate') echo "selected";?>>Date</option>
                                          </select>
                                       </div>
                                    </div>

                                    <div class="col-lg-2 drp" style="<?php echo $purchasesearch=='thisDate'?'display:inline-block':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label>Date</label>
                                          <!-- <input class="form-control m-input m-input--square" id="m_daterangepicker_3" name="dtrange" placeholder="Choose Date" value="" type="text"> -->
                                          <div class="m-input-icon pull-right" id='m_daterangepicker_3'>
                                             <input class="form-control m-input m-input--square" id="m_daterangepicker_3" name="dtrange" placeholder="Choose Date" value="<?php echo $drnge;?>" type="text">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 drp" style="<?php echo $purchasesearch=='thisDate'?'display:inline-block':'display:none';?>">
                                       <div class="form-group m-form__group">
                                          <label></label>
                                          <input id="goButton" name="goButton" value="Go" class="btn btn-primary inp" style="margin-top:26px;" type="submit">
                                       </div>
                                    </div>
                                 
                                 </div>
                              </form>

                              <div class="row"> 
                                 <div class="col-lg-12">  
                                    <table class="table table-striped- table-bordered table-hover table-checkable" id="m_table_2">
                                       <thead>
                                          <tr>
                                             <th>Quote No</th>
                                             <th>Exporter</th>
                                             <th>Subject</th>
                                             <th>Consignee</th>
                                             <th>No.of Products</th>
                                             <th>Value</th>
                                             <th>Stages</th>
                                             <th>Assigned To</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <?php $i=0;foreach ($quote_list as $qlist){
                                             $quotlist = $this->Quote_model->get_quote_by_id($qlist['qid']);
                                             $qprod = $this->Quote_model->get_quote_product_by_quote_id($qlist['qid']);
                                             $get_value_variant_by_quote_Value = get_value_variant_by_value($quotlist->grand_total);
                                             $value_based_color = $get_value_variant_by_quote_Value->vv_color;
                                          ?>
                                          <tr>
                                             <td>
                                                
                                                <h5 class="text-black" style="margin-bottom: 0px;"><?php echo $qlist['quote_no'];?></h5> <?php if($qlist['qcount']>1){?><span class="m-badge m-badge--info pull-right tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="<?php echo $qlist['qcount']-1; ?> QTN Revised"><?php echo $qlist['qcount']-1; ?></span><?php }?>
                                                <span style="font-size: 16.5px;" class="text-muted"><b><sub><?php echo date($date_format, strtotime($quotlist->created_date)); ?> / <?php echo date($date_format, strtotime($quotlist->valid_till)); ?></sub><b></b></b></span>
                                                
                                             </td> 
                                             <td>
                                                <?php echo $quotlist->exporter_name;?>
                                             </td>
                                             <td>
                                                <?php echo $quotlist->subject;?>
                                             </td>
                                             <td>
                                                <h5 class="text-black" style="margin-bottom: 0px;"><?php echo $quotlist->lead_name;?></h5>
                                                <span style="font-size: 16.5px;" class="text-muted"><b><sub><?php echo $quotlist->country_name; ?></sub><b></b></b></span>
                                             </td>
                                             <td align="center">
                                                <h5 class="text-black"><?php echo count($qprod);?></h5>
                                             </td>
                                             <td class="grand_total" style="background-color: <?php echo $value_based_color; ?>;">
                                                <h5 class="text-black">
                                                   <span class="pull-left">
                                                      <i class="fa fa-rupee-sign"></i>
                                                   </span>
                                                   <span class="pull-right"><?php echo number_format($quotlist->grand_total,2);?></span>
                                                </h5>
                                                <h6 class="text-primary curr_amnt_info">
                                                   <span class="pull-right"> <?php $convert_curr = $quotlist->grand_total / $quotlist->rate; echo $quotlist->currency_code.' '.number_format($convert_curr,2); ?></span>
                                                </h6>
                                             </td>
                                             <td>
                                               <h5 class="text-black"><?php echo $quotlist->quote_stage; ?></h5>
                                             </td>
                                             <td>
                                                <?php echo $quotlist->lead_assigned_name;?>
                                             </td>
                                             <td>
                                                <?php if($_SESSION['Quote ManagementView']==1){ ?>
                                                <a href="<?php echo base_url(); ?>quote/quote_view/<?php echo $quotlist->quote_id;?>"><span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="View"><i class="fa fa-info-circle"></i></span></a>&nbsp;&nbsp;
                                                <?php }?>
                                                <?php if($_SESSION['Quote ManagementEdit']==1){ ?>
                                                <a href="<?php echo base_url(); ?>quote/quote_edit/<?php echo $quotlist->quote_id;?>"><span class="tooltip-animation" data-toggle="m-tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></span></a>
                                                <?php }?>
                                                
                                             </td>
                                          </tr>
                                          <?php $i++;}?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  <!--End::Section-->
               </div>
            </div>
         </div>
         <div class="container">
            <div class="modal fade" id="quote_export_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
               <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Export Quote Info</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <form action="<?php echo base_url(); ?>Leads/export_quote_info" method="POST">
                        <div class="modal-body">
                           <div class="row">
                              <div class="col-lg-12">
                                 <div class="form-group m-form__group">
                                    <h3>Filter By<span class="text-danger"></span></h3>
                                    <div class="row">
                                       <div class="col-lg-3">
                                          <div class="">
                                             <label class="">
                                               <label class="label" style="color: #2D4A89;">Year</label>
                                               <input type="hidden" name="exp_quote_filt_year_val" id="exp_quote_filt_year_val">
                                               <input type="hidden" name="quarter_or_range" id="quarter_or_range">
                                               <span id="exp_quote_filt_year"></span>
                                             </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-3">
                                          <div class="">
                                             <label class="">
                                               <label class="label" style="color: #2D4A89;">Quarter</label>
                                               <input type="hidden" name="exp_quote_filt_quarter_val" id="exp_quote_filt_quarter_val">
                                               <span id="exp_quote_filt_quarter"></span>
                                             </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-3">
                                          <div class="">
                                             <label class="">
                                               <label class="label" style="color: #2D4A89;">Search By :</label>
                                               <input type="hidden" name="exp_quote_filt_search_val" id="exp_quote_filt_search_val">
                                               <span id="exp_quote_filt_search"></span>
                                             </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-3">
                                          <div class="">
                                             <label class="">
                                               <label class="label" style="color: #2D4A89;">Date Range Wise :</label>
                                               <input type="hidden" name="exp_quote_filt_dtrng_val" id="exp_quote_filt_dtrng_val">
                                               <span id="exp_quote_filt_dtrng"></span>
                                             </label>
                                          </div>
                                       </div>
                                    </div>
                                    
                                 </div>
                              </div>
                           </div>
                           <hr>
                           <div class="row">
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_lead_name" checked class = "quote_export" name="quote_export[]" value="Lead Name"><label class="label" for="exp_lead_name">Lead Name</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_quo_no" checked class = "quote_export" name="quote_export[]" value="Quote No"><label class="label" for="exp_quo_no">Quote No</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_exporter" checked class = "quote_export" name="quote_export[]" value="Exporter"><label class="label" for="exp_exporter">Exporter</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_subject" checked class = "quote_export" name="quote_export[]" value="Subject"><label class="label" for="exp_subject">Subject</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_cre_date" checked class = "quote_export" name="quote_export[]" value="Created Date"><label class="label" for="exp_cre_date">Created Date</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_valid_date" class = "quote_export" name="quote_export[]" value="Valid Date"><label class="label" for="exp_valid_date">Valid Date</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_quo_stage" checked class = "quote_export" name="quote_export[]" value="Quote Stage"><label class="label" for="exp_quo_stage">Quote Stage</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_pri_val" class = "quote_export" name="quote_export[]" value="Price Validity"><label class="label" for="exp_pri_val">Price Validity</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_vessel" class = "quote_export" name="quote_export[]" value="Vessel flight"><label class="label" for="exp_vessel">Vessel flight</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_from_port" class = "quote_export" name="quote_export[]" value="From Port"><label class="label" for="exp_from_port">From Port</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_to_port" class = "quote_export" name="quote_export[]" value="To Port"><label class="label" for="exp_to_port">To Port</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_pri_term" class = "quote_export" name="quote_export[]" value="Price Term"><label class="label" for="exp_pri_term">Price Term</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_currency" checked class = "quote_export" name="quote_export[]" value="Currency"><label class="label" for="exp_currency">Currency</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_rate" class = "quote_export" name="quote_export[]" value="Rate"><label class="label" for="exp_rate">Rate</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              <div class="col-lg-3">
                                 <div class="bank m-checkbox-inline">
                                    <label class="m-checkbox">
                                      <input type="checkbox" id="exp_g_tot" checked class = "quote_export" name="quote_export[]" value="Grand Total"><label class="label" for="exp_g_tot">Grand Total</label>
                                      <span></span>
                                    </label>
                                 </div>
                              </div>
                              
                           </div>


                        </div>
                        <div class="modal-footer">
                           <div class="bank m-checkbox-inline">
                              <label class="m-checkbox">
                                <input type="checkbox" onclick="toggle(this)"><label class="label">All</label>
                                <span></span>
                              </label>
                           </div>&nbsp;
                          <button type="submit" class="btn btn-primary">Yes</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
         <!-- end:: Body -->

         <!-- begin::Footer -->
         <?php $this->load->view('common_footer'); ?>

         <!-- end::Footer -->
      </div>

      <!-- end:: Page -->


<script type="text/javascript">
   var baseurl = '<?php echo base_url(); ?>';
   var title = $('title').text() + ' | ' + 'Quote List';
   $(document).attr("title", title);
$(document).ready(function(){
   var quarter = $('#fquarter').val();
   var ypick = $('#ypick').val();
   var search = $('#searchChange').val();
   var dtrnge = $('#m_daterangepicker_3').val();
   var fbase = $('#fbase').val();

   $('#exp_quote_filt_year').empty().append(ypick);
   $('#exp_quote_filt_year_val').empty().val(ypick);

   $('#exp_quote_filt_quarter').empty().append(quarter);
   $('#exp_quote_filt_quarter_val').empty().val(quarter);

   $('#exp_quote_filt_search').empty().append(search);
   $('#exp_quote_filt_search_val').empty().val(search);

   $('#exp_quote_filt_dtrng').empty().append(dtrnge);
   $('#exp_quote_filt_dtrng_val').empty().val(dtrnge);

   $('#quarter_or_range').empty().val(fbase);
});
function quote_export_items()
{
   $('#quote_export_model').modal('show');
}
function toggle(source) {
      
  checkboxes = document.getElementsByClassName('quote_export');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}
function showFilterDate(){
    
    var filterBy = $('#searchChange').val(); 
    if(filterBy == 'thisDate')
    {
        $('.drp').show();
    }
    else{
        $('.drp').hide();
    }
}

function showFBase()
{

   var bon = $('#fbase').val();
   $('#quarter_or_range').empty().val(bon);
   if(bon=='BonQuarter')
   {
      $('.bod').hide();
      $('.boq').show();
   }
   else
   {
      $('.bod').show();
      $('.boq').hide();
   }
}

var toDate = $('#ypick').datepicker({
    format: "yyyy",
    minViewMode: 2,
  autoclose : true
    }).on('hide',function(date){
  $("#ypick").val(date.target.value + "-" + (parseInt(date.target.value) + parseInt(1)));
});

</script>


   </body>

   <!-- end::Body -->
</html>