<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* ************************************************************************************
		Purpose : To handle all login functions
		Date    : 03-02-2020 
***************************************************************************************/
class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array("Login_model"));
		// $this->load->database();
  //   $this->db->hostname('localhost');
  //   $this->db->username('root');
  //   $this->db->password('');
  //   $this->db->database('rajexim_july15_2020');
    // $this->load->library('nativesession');
		date_default_timezone_set("Asia/Kolkata");
	}
	/* ************************************************************************************
						Purpose : To handle admin login function 
	        **********************************************************************/
	public function index()
	{
      
		  $this->load->view('login');
	}

  public function db_config()
  {
    
    if (isset($_GET['auth_db'])) {
      $url_code = $_GET['auth_db'];
      if ($url_code == "UFltekh3QlFVRHl0d0ZRV25KMTNIZz09") {
        $this->load->view('db_configuration');
      }
      else {
        echo "Access Denied!";
      }
    }
    else {
      echo "Invalid Access...";
    }
      
  }
  public function db_dyno_config()
  {
    $data['err'] = '';
    if(isset($_POST['sub'])){
      $host = $_POST['host'];
      $uname = $_POST['username'];
      $pass = $_POST['pass'];
      $db = $_POST['dbname'];
     
      $conn = new mysqli($host, $uname, $pass);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      } 
      $sql = "CREATE DATABASE $db";
      if ($conn->query($sql) === TRUE) {
          $data['err'] = "Database created successfully with the name newDB";
      } else {
          $data['err'] = "Error creating database: " . $conn->error;
      }
      
      $conn->close();

      $conn1 = mysqli_connect($host, $uname, $pass, $db);
      
      $query = '';
      $sqlScript = file('assets/source_db/first.sql');
     
      $i=1;

      $total_query = count($sqlScript);
     
      $all_query_succ = 0;
      foreach ($sqlScript as $line) {
       
        $startWith = substr(trim($line), 0 ,2);
        $endWith = substr(trim($line), -1 ,1);
        
        if (empty($line) || $startWith == '--' || $startWith == '/*' || $startWith == '//') {
          continue;
        }
          
        $query = $query . $line;
        if ($endWith == ';') {
          $query = str_replace(';', '', $query);
        
          $flag = mysqli_query($conn1,$query) or die('<div class="error-response sql-import-response">Problem in executing the SQL query <b>' . $query. '</b></div>');
          $query= '';  
        }
        $i++;
      }
     
        if(file_exists('application/config/database.php')){
            $myfile = fopen("application/config/database.php", "w") or die("Unable to open file!");
            $txt = "<?php ";
            fwrite($myfile, $txt);
            $txt = "defined('BASEPATH') or exit('No direct script access allowed');\n";
            fwrite($myfile, $txt);
            $txt = "$";
            fwrite($myfile, $txt);
            $txt = "active_group = 'default';\n";
            fwrite($myfile, $txt);
            $txt = "$";
            fwrite($myfile, $txt);
            $txt = "query_builder = true;\n";
            fwrite($myfile, $txt);
            $txt = "$";
            fwrite($myfile, $txt);
            $txt = "db['default']=array(";
            fwrite($myfile, $txt);
            $txt = "'dsn' => '','hostname' => '".$host."','username' => '".$uname."', 'password' => '".$pass."', 'database' => '".$db."', 'dbdriver' => 'mysqli', 'dbprefix' => '', 'pconnect' => false, 'db_debug' => (ENVIRONMENT !== 'production') , 'cache_on' => false, 'cachedir' => '', 'char_set' => 'utf8', 'dbcollat' => 'utf8_general_ci', 'swap_pre' => '', 'encrypt' => false, 'compress' => false, 'stricton' => false, 'failover' => array() , 'save_queries' => true );";
            fwrite($myfile, $txt);
            fclose($myfile);
        }
        else {
            echo "Database file doesn't exist";
        }
      
      redirect('Login/db_config');
    }
  }
	public function admin_login_check()
	{ 
	  $username = $this->input->post('name'); 
	  $userin   = $this->input->post('password');
	  $rememberme = $this->input->post('rememberme');
	  $row_res = $this->Login_model->admin_login_details($username);
	  $row_count = (!empty($row_res)) ? $row_res : 0;
	  if($username == "" && $userin !='' )
	  {
      $ip = $_SERVER['REMOTE_ADDR'];
      $txt = "[".date('Y-m-d H:i:s')."] => ".$ip."  -   -  username is empty";
      $mostRecentFilePath = "";
      $mostRecentFileMTime = 0;

      $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("Logs/Login Logs"), RecursiveIteratorIterator::CHILD_FIRST);
      foreach ($iterator as $fileinfo) {
          if ($fileinfo->isFile()) {
              if ($fileinfo->getMTime() > $mostRecentFileMTime) {
                  $mostRecentFileMTime = $fileinfo->getMTime();
                  $mostRecentFilePath = $fileinfo->getPathname();
              }
          }
      }

      $fsize = filesize($mostRecentFilePath);
      if($fsize>1000000)
        $myfile = file_put_contents('Logs/Login Logs/login_log-'.date("Y-m-d").'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
      else
        $myfile = file_put_contents($mostRecentFilePath, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
	    echo 1;
	  }
	  else if($userin==""&&$username!='')
	  {
      $ip = $_SERVER['REMOTE_ADDR'];
      $txt = "[".date('Y-m-d H:i:s')."] => ".$ip."  -  " .$username. "  -  Password is empty";
      $mostRecentFilePath = "";
      $mostRecentFileMTime = 0;

      $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("Logs/Login Logs"), RecursiveIteratorIterator::CHILD_FIRST);
      foreach ($iterator as $fileinfo) {
          if ($fileinfo->isFile()) {
              if ($fileinfo->getMTime() > $mostRecentFileMTime) {
                  $mostRecentFileMTime = $fileinfo->getMTime();
                  $mostRecentFilePath = $fileinfo->getPathname();
              }
          }
      }

      $fsize = filesize($mostRecentFilePath);
      if($fsize>1000000)
        $myfile = file_put_contents('Logs/Login Logs/login_log-'.date("Y-m-d").'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
      else
        $myfile = file_put_contents($mostRecentFilePath, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
	    echo 2;
	  }
	  else if($username == "" && $userin == "")
	  {
      $ip = $_SERVER['REMOTE_ADDR'];
      $txt = "[".date('Y-m-d H:i:s')."] => ".$ip."  -    -  Username & Password is empty";
      $mostRecentFilePath = "";
      $mostRecentFileMTime = 0;

      $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("Logs/Login Logs"), RecursiveIteratorIterator::CHILD_FIRST);
      foreach ($iterator as $fileinfo) {
          if ($fileinfo->isFile()) {
              if ($fileinfo->getMTime() > $mostRecentFileMTime) {
                  $mostRecentFileMTime = $fileinfo->getMTime();
                  $mostRecentFilePath = $fileinfo->getPathname();
              }
          }
      }

      $fsize = filesize($mostRecentFilePath);
      if($fsize>1000000)
        $myfile = file_put_contents('Logs/Login Logs/login_log-'.date("Y-m-d").'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
      else
        $myfile = file_put_contents($mostRecentFilePath, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
	    echo 3;
	  }
	  
	  else if(!empty($row_res) && $row_res->status==1)
	  {
      $ip = $_SERVER['REMOTE_ADDR'];
      $txt = "[".date('Y-m-d H:i:s')."] => ".$ip."  -  " .$username. "  -  User Inactive";
      $mostRecentFilePath = "";
      $mostRecentFileMTime = 0;

      $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("Logs/Login Logs"), RecursiveIteratorIterator::CHILD_FIRST);
      foreach ($iterator as $fileinfo) {
          if ($fileinfo->isFile()) {
              if ($fileinfo->getMTime() > $mostRecentFileMTime) {
                  $mostRecentFileMTime = $fileinfo->getMTime();
                  $mostRecentFilePath = $fileinfo->getPathname();
              }
          }
      }

      $fsize = filesize($mostRecentFilePath);
      if($fsize>1000000)
        $myfile = file_put_contents('Logs/Login Logs/login_log-'.date("Y-m-d").'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
      else
        $myfile = file_put_contents($mostRecentFilePath, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
	    echo 5;
	  }
	  else if(!empty($row_res) && $row_res->status==0)
	  {

      $logpass = decryptthis($row_res->password,'Rajexim2020');

      if($userin == $logpass)
      {
        $mydata = array('username' => $row_res->username , 'user_id' => $row_res->user_id, 'role_id' => $row_res->role_id, 'show_menu' => $row_res->show_menu);
        $rolep = $this->Login_model->get_role_permission_by_role_id($row_res->role_id);
        foreach($rolep as $rp)
        {
          $rpf = explode('~', $rp['fields']);
          $rpv = explode('~', $rp['value']);
          $crpf = count($rpf);
          for($i=0;$i<$crpf;$i++)
          {
            $this->session->set_userdata($rp['menu_name'].$rpf[$i],$rpv[$i]);
            $mydata[$rp['menu_name'].$rpf[$i]] = $rpv[$i];
          }
        }
        $ip = $_SERVER['REMOTE_ADDR'];
        $txt = "[".date('Y-m-d H:i:s')."] => ".$ip."  -  ".$row_res->username."  -  Success";
        $mostRecentFilePath = "";
        $mostRecentFileMTime = 0;

        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("Logs/Login Logs"), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($iterator as $fileinfo) {
            if ($fileinfo->isFile()) {
                if ($fileinfo->getMTime() > $mostRecentFileMTime) {
                    $mostRecentFileMTime = $fileinfo->getMTime();
                    $mostRecentFilePath = $fileinfo->getPathname();
                }
            }
        }

        $fsize = filesize($mostRecentFilePath);
        if($fsize>1000000)
          $myfile = file_put_contents('Logs/Login Logs/login_log-'.date("Y-m-d").'.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
        else
          $myfile = file_put_contents($mostRecentFilePath, $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
        //print_r($mydata);exit;
        $financial_year_to = (date('m') > 3) ? date('Y') +1 : date('Y');
        $financial_year_from = $financial_year_to - 1;
        $finstart = $financial_year_from.'-04-01';
        $finend = $financial_year_to.'-03-31';

        $get_all_users_email = $this->Login_model->get_all_user_own_mail_by_id($row_res->user_id);

        $login_time = date('Y-m-d H:i:s');
        $user_ip = getenv("REMOTE_ADDR");
        $store_login_time = $this->Login_model->store_login_time($row_res->user_id,$login_time,$user_ip);

        $this->session->set_userdata('login_history_id', $store_login_time);


        $this->session->set_userdata('finstart', $finstart);
        $this->session->set_userdata('finend', $finend);
        $this->session->set_userdata('admindata',$mydata);
        $this->session->set_userdata('user_own_emails',$get_all_users_email);
        $this->session->set_userdata('appuser_roleid',$row_res->role_id);
        session_start();
        $_SESSION['appuser_roleid'] = $this->session->userdata('appuser_roleid');
        // $this->nativesession->set('appuser_roleid', $row_res->role_id);
        if($rememberme==1)
        {
          set_cookie("username",$username,'7200');
          set_cookie("password",$userin,'7200');
          set_cookie("rememberme",'1','7200');
        }
  	    else if($rememberme==0)
  	    {
  	        delete_cookie("username");
  	        delete_cookie("password");
  	        delete_cookie("rememberme");
  	    }
  	         echo 6;
  		}
  	 }
	}
	// To logout
	public function logout()
	{
    $login_history_id = $this->session->userdata('login_history_id');
    $get_log_hist_by_id = $this->Login_model->get_log_hist_by_id($login_history_id);

    $login_time = $get_log_hist_by_id->login_time;
    $logout_time = date('Y-m-d H:i:s');
    $datetime1 = strtotime($logout_time);
    $datetime2 = strtotime($get_log_hist_by_id->login_time);

    $secs = $datetime1 - $datetime2;
    $diff_log = gmdate("H:i:s", $secs);
    
    $update_logout_time = $this->Login_model->update_logout_time($login_history_id,$logout_time,$diff_log);
    if ($update_logout_time == 1) {
  	  $user_data = $this->session->all_userdata();
  	  foreach ($user_data as $key => $value) {
  	            $this->session->unset_userdata($key);
  	    }

  	  
    }
    redirect(base_url("login"));
	}

  // To show 404 page
  public function show_404_page()
  {
  	$this->load->view('404_page');
  }
  public function export_backup_db()
  {
    $link = mysqli_connect('localhost','root','','rajexim_june17_2020');
  // mysqli_select_db($name,$link);
  $tables = '*';
  //get all of the tables
  if($tables == '*')
  {
    $tables = array();
    $result = mysqli_query($link,'SHOW TABLES');
    while($row = mysqli_fetch_row($result))
    {
      $tables[] = $row[0];
    }
  }
  else
  {
    $tables = is_array($tables) ? $tables : explode(',',$tables);
  }
  $return = '';
  //cycle through
  foreach($tables as $table)
  {
    $result = mysqli_query($link,'SELECT * FROM '.$table);
    $num_fields = mysqli_num_fields($result);
    
    $return.= 'DROP TABLE '.$table.';';
    $row2 = mysqli_fetch_row(mysqli_query($link,'SHOW CREATE TABLE '.$table));
    $return.= "\n\n".$row2[1].";\n\n";
    
    for ($i = 0; $i < $num_fields; $i++) 
    {
      while($row = mysqli_fetch_row($result))
      {
        $return.= 'INSERT INTO '.$table.' VALUES(';
        for($j=0; $j < $num_fields; $j++) 
        {
          $row[$j] = addslashes($row[$j]);
          // $row[$j] = preg_replace("\n","\\n",$row[$j]);
          $row[$j] = preg_replace("#\n#","\\n",$row[$j]);
          if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
          if ($j < ($num_fields-1)) { $return.= ','; }
        }
        $return.= ");\n";
      }
    }
    $return.="\n\n\n";
  }
  
  //save file
  $handle = fopen('assets/db_backup/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
  fwrite($handle,$return);
  fclose($handle);
  }
}
?>